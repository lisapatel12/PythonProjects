Python 3.9.1 (v3.9.1:1e5d33e9b9, Dec  7 2020, 12:44:01) 
[Clang 12.0.0 (clang-1200.0.32.27)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=========== RESTART: /Users/naileshpatel/Downloads/Tip_Calculator.py ===========
Enter the subtotal: $1250
Enter tip: %25

~RECEIPT~
Subtotal: $1,250.00
Tip: 25%
-----
Total: $1,562.50

Have a nice day :)
>>> 