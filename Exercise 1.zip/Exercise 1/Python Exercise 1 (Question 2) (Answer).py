Python 3.9.1 (v3.9.1:1e5d33e9b9, Dec  7 2020, 12:44:01) 
[Clang 12.0.0 (clang-1200.0.32.27)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=== RESTART: /Users/naileshpatel/Documents/Python Exercise 1 (Question 2).py ===
Enter the take-off speed: 60
Enter the airplane's acceleration: 3.5
The minimum runway length needed for this airplane is 514.2857 meters.
>>> 