Python 3.9.1 (v3.9.1:1e5d33e9b9, Dec  7 2020, 12:44:01) 
[Clang 12.0.0 (clang-1200.0.32.27)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
==== RESTART: /Users/naileshpatel/Documents/Python Exercise 1 Question 1.py ====
Enter the x-coordinate for point1: 4.5
Enter the y-coordinate for point1: -5.5
Enter the x-coordinate for point2: 6.6
Enter the y-coordinate for point2: -6.5
The slope for the line that connects two points (4.5,-5.5) and(6.6,-6.5) is -0.47619
>>> 