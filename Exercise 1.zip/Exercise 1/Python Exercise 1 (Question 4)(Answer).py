Python 3.9.1 (v3.9.1:1e5d33e9b9, Dec  7 2020, 12:44:01) 
[Clang 12.0.0 (clang-1200.0.32.27)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
========== RESTART: /Users/naileshpatel/Downloads/Area_of_a_Hexagon.py =========
Enter the side length of your hexagon: 5.5
The area of your hexagon is 78.592
>>> 